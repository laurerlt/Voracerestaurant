VORACE – Site Web

Ce dossier contient les fichiers nécessaires pour héberger le site web du restaurant Vorace.

Structure :
- index.html : la page principale du site
- fonts/ : dossier pour ajouter la police Areqo (ajoutez areqo.woff2 et areqo.woff)
- images/ : dossier pour votre image WhatsApp ou autres visuels

💡 Hébergement recommandé :
- Netlify (https://netlify.com) : glissez-déposez le dossier
- GitHub Pages : créez un dépôt et activez GitHub Pages dans les paramètres

Modifications :
Vous pouvez ouvrir index.html avec n'importe quel éditeur de texte pour faire vos changements.
